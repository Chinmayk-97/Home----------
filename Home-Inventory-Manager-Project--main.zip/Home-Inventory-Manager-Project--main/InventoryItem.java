package homeinventory;
public class InventoryItem
{
public String description;
public String location;
public boolean marked;

public String serialNumber;
public String purchasePrice;
public String purchaseDate;
public String purchaseLocation;
public String note;
public String photoFile;
}
