# Home-Inventory-Manager-Project-
# Problem statement : How does one calculate the worth of the House Hold goods and equipment's when taking a Household Insurance policy.

# Abstract : The Home Inventory Manager Project helps you keep track of your valuable belongings. For every item in your inventory, the program stores a description, location, serial number, purchase information, and even a photo. A printed inventory is available - very useful for insurance purposes. This coding Internship project would re-inforce some object-oriented programming concepts and how to print from a project.
